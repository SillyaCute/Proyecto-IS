package businessLogic;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import domain.ConcreteFlight;
import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public interface FlightManagerInterface{
	@WebMethod
	public List<String> getAllDepartingCities();
	@WebMethod
	public List<String> getArrivalCitiesFrom(String departingCity);
	@WebMethod
	public Collection<ConcreteFlight> getConcreteFlights(String departingCity, String arrivingCity, Date date);
}