package domain;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlID;

@Entity
@XmlAccessorType(XmlAccessType.FIELD)
public class Flight {
@Id
@XmlID
String flightCode;
String departingCity;
String arrivingCity;

@Transient
Collection<ConcreteFlight> concreteFlights;

public Flight(String flightCode, String departingCity, String arrivingCity) {
	super();
	
	this.flightCode = flightCode;
	this.departingCity = departingCity;
	this.arrivingCity = arrivingCity;
	concreteFlights = new ArrayList<ConcreteFlight>();
}

public String getFlightCode() {
	return flightCode;
}
public void setFlightCode(String flightCode) {
	this.flightCode = flightCode;
}
public String getDepartingCity() {
	return departingCity;
}
public void setDepartingCity(String departingCity) {
	this.departingCity = departingCity;
}
public String getArrivingCity() {
	return arrivingCity;
}
public void setArrivingCity(String arrivingCity) {
	this.arrivingCity = arrivingCity;
}

public void addConcreteFlight(String concreteFlighCode, Date date, int businessNumber, int firstNumber, int touristNumber, String time){
	ConcreteFlight cf=new ConcreteFlight(concreteFlighCode,date, businessNumber,firstNumber,touristNumber,time, this);
	concreteFlights.add(cf);
}

public void addVueloConcreto(ConcreteFlight cf) {
	concreteFlights.add(cf);
}

public Collection<ConcreteFlight> getConcreteFlights() {
	return concreteFlights;
}

public void setConcreteFlights(Collection<ConcreteFlight> concreteFlights) {
	this.concreteFlights = concreteFlights;
}
public String toString() {return flightCode+"/"+departingCity+"/"+arrivingCity;}

public void addConcreteFlight(ConcreteFlight cf) {
    concreteFlights.add(cf);
}

public boolean vueloIgual(Flight vuelo) {
	return ((this.flightCode.equals(vuelo.flightCode)) && (this.arrivingCity.equals(vuelo.arrivingCity)) && (this.departingCity.equals(vuelo.departingCity)));
}

}
