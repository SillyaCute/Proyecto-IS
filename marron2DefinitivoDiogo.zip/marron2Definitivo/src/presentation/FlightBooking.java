package presentation;


import javax.swing.JPanel;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.net.MalformedURLException;
import java.net.URL;
import java.awt.EventQueue;
import java.awt.List;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;

import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;

import businessLogic.FlightManager;

import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.border.EmptyBorder;

import businessLogic.FlightManagerInterface;
import domain.ConcreteFlight;

public class FlightBooking extends JFrame {
	
	
	//Esto es lo nuevo 
	private static FlightManagerInterface wsl=null;
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane= null;
	private JLabel lblDepartCity = new JLabel("Departing city:");
	private JLabel lblArrivalCity = new JLabel("Arrival City");
	private JLabel lblYear = new JLabel("Year:");
	private JLabel lblRoomType = new JLabel("Room Type:");
	private JLabel lblMonth = new JLabel("Month:");
	private JLabel lblDay = new JLabel("Day:");;
	private JLabel jLabelResult = new JLabel();
	private JLabel searchResult =   new JLabel();
	private JTextField day = null;
	private JComboBox<String> months = null;
	private DefaultComboBoxModel<String> monthNames = new DefaultComboBoxModel<String>();

	private JTextField year = null;
	
	private JRadioButton bussinesTicket = null;
	private JRadioButton firstTicket = null;
	private JRadioButton touristTicket = null;

	private ButtonGroup fareButtonGroup = new ButtonGroup();  
	
	private JButton lookforFlights = null;
	private DefaultListModel<ConcreteFlight> flightInfo = new DefaultListModel<ConcreteFlight>();

	
	private JList<ConcreteFlight> flightList = null;
	private JButton bookFlight = null;
	
	

	
	private Collection<ConcreteFlight> concreteFlightCollection;
	
	private FlightManager businessLogic;
	
	private FlightManager fm;
	private ConcreteFlight selectedConcreteFlight;
	//Los jcomboBox
	private JComboBox departCity = new JComboBox();
	private DefaultComboBoxModel<String> departCityNames= new DefaultComboBoxModel<String>();

	private JComboBox arrivalCity = new JComboBox();
	private DefaultComboBoxModel<String> arrivalCityNames= new DefaultComboBoxModel<String>();
	
	private final JComboBox flightBox = new JComboBox();
	private DefaultComboBoxModel<String> flightBoxNames= new DefaultComboBoxModel<String>();

	

	/**
	 * Launch the application.
	 */

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {

					//Esto es la parte de URL
					URL url = new URL("http://0.0.0.0:9999/ws?wsdl");
					QName qname = new QName("http://service/","WebServiceLogicService");
					Service service = Service.create(url, qname);
					wsl = service.getPort(FlightManagerInterface.class);
					
					FlightBooking frame = new FlightBooking();
					frame.setBusinessLogic(new FlightManager());
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	//Custom operations
	public void setBusinessLogic(FlightManager g) {
		businessLogic = g; 
		fm=g;
		cargarCombosIniciales();
	}
	
	private void cargarCombosIniciales() {

	    ArrayList<String> a = (ArrayList<String>) fm.getAllDepartingCities();

	    departCityNames.removeAllElements();
	    for (String s : a) {
	        departCityNames.addElement(s);
	    }

	    arrivalCityNames.removeAllElements();
	    if (!a.isEmpty()) {
	        for (String s : fm.getArrivalCitiesFrom(a.get(0))) {
	            arrivalCityNames.addElement(s);
	        }
	    }
	}
	
	private Date newDate(int year,int month,int day) {

	     Calendar calendar = Calendar.getInstance();
	     calendar.setLenient(false); // This is to avoid use heuristics to parse inputs as dates
	     calendar.set(year, month, day,0,0,0);
	     calendar.set(Calendar.MILLISECOND, 0);

	     return calendar.getTime();
	}
	


	/**
	 * Create the frame
	 * 
	 * @return void
	 */
	private  FlightBooking() {
		
		setTitle("Book Flight");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Runtime.getRuntime().addShutdownHook(
			    new Thread(new Runnable() {
			        @Override
			        public void run() {
			            if (businessLogic != null) businessLogic.close();
			        }
			    })
		);
	
		setBounds(100, 100, 450, 353);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		contentPane.add(searchResult);
		
		//Esta parte es la del flight box del apartado 5 que queria.
		flightBox.setBounds(67, 157, 314, 24);
		contentPane.add(flightBox);
		flightBox.setModel(flightBoxNames);
		flightBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(flightBox.getSelectedItem()!=null) {
					String temp = flightBox.getSelectedItem().toString();
					java.util.Date date;
					bookFlight.setText(temp);
					try {
						date = newDate(Integer.parseInt(year.getText()),months.getSelectedIndex(),Integer.parseInt(day.getText()));
						concreteFlightCollection=businessLogic.getConcreteFlights(departCity.getSelectedItem().toString(),arrivalCity.getSelectedItem().toString(),date);

						for (ConcreteFlight f : concreteFlightCollection) {
							if(f.toString().equals(temp)) {
								bussinesTicket.setEnabled(false);
								firstTicket.setEnabled(false);
								touristTicket.setEnabled(false);
								if(f.getBusinessNumber()>0) {
									bussinesTicket.setEnabled(true);
								}
								if(f.getFirstNumber()>0) {
									firstTicket.setEnabled(true);
								}
								if(f.getTouristNumber()>0) {
									touristTicket.setEnabled(true);
								}
								selectedConcreteFlight = f;
								break;
							}
						}
					}catch(Exception ek) {
						bussinesTicket.setEnabled(false);
						firstTicket.setEnabled(false);
						touristTicket.setEnabled(false);
					}
				}
			}
		});
		
		//Parte de arrival city
		arrivalCity.setBounds(112, 33, 243, 23);
		contentPane.add(arrivalCity);
		arrivalCity.setModel(arrivalCityNames);

		//Parte de departCity
		departCity = new JComboBox<String>();
		departCity.setBounds(112, 6, 243, 23);
		contentPane.add(departCity);
		departCity.setModel(departCityNames);

		//Para cuando se selecciona una acciono algun cambio en la aplicacion
		departCity.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				ArrayList<String> a = (ArrayList<String>) fm.getArrivalCitiesFrom(departCity.getSelectedItem().toString());
				arrivalCityNames.removeAllElements();
				for(int i = 0; i<a.size();i++) {
					arrivalCityNames.addElement(a.get(i));
				}
			}
		});		
		
		
		
		months = new JComboBox<String>();
		months.setBounds(163, 58, 116, 27);
		contentPane.add(months);
		months.setModel(monthNames);
		
		monthNames.addElement("January");
		monthNames.addElement("February");
		monthNames.addElement("March");
		monthNames.addElement("April");
		monthNames.addElement("May");
		monthNames.addElement("June");
		monthNames.addElement("July");
		monthNames.addElement("August");
		monthNames.addElement("September");
		monthNames.addElement("October");
		monthNames.addElement("November");
		monthNames.addElement("December");
		months.setSelectedIndex(1);

		
		lblDepartCity = new JLabel("Depart City");
		lblDepartCity.setBounds(21, 11, 103, 16);
		contentPane.add(lblDepartCity);
		
		
		lblYear = new JLabel("Year:");
		lblYear.setBounds(21, 62, 33, 16);
		contentPane.add(lblYear);
		
		lblMonth = new JLabel("Month:");
		lblMonth.setBounds(117, 62, 50, 16);
		contentPane.add(lblMonth);
	    
		
		lblDay = new JLabel("Day:");
		lblDay.setBounds(291, 62, 38, 16);
		contentPane.add(lblDay);
		
		day = new JTextField();
		day.setText("23");
		day.setBounds(331, 57, 50, 26);
		contentPane.add(day);
		day.setColumns(10);
		
		lblRoomType = new JLabel("Seat Type:");
		lblRoomType.setBounds(21, 242, 84, 16);
		contentPane.add(lblRoomType);
		
		
		
		bussinesTicket = new JRadioButton("Business");
		fareButtonGroup.add(bussinesTicket);
		bussinesTicket.setBounds(99, 238, 101, 23);
		contentPane.add(bussinesTicket);
		bussinesTicket.setEnabled(false);
		bussinesTicket.setSelected(false);
		//agregado para el 						bookFlight.setEnabled(true);
		bussinesTicket.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				bookFlight.setEnabled(true);
			}
		});
		
		firstTicket = new JRadioButton("First");
		fareButtonGroup.add(firstTicket);
		firstTicket.setBounds(202, 238, 77, 23);
		contentPane.add(firstTicket);
		firstTicket.setEnabled(false);
		firstTicket.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				bookFlight.setEnabled(true);
			}
		});
		
		touristTicket = new JRadioButton("Tourist");
		fareButtonGroup.add(touristTicket);
		touristTicket.setBounds(278, 238, 77, 23);
		contentPane.add(touristTicket);
		touristTicket.setEnabled(false);
		touristTicket.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				bookFlight.setEnabled(true);
			}
		});
		
		//Ver si hay vuelos.
		lookforFlights = new JButton("Look for Concrete Flights");
		lookforFlights.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bookFlight.setEnabled(false);
				flightBoxNames.removeAllElements();
				bookFlight.setText("");
				//Echo cambios para el año o fecha para ver si alguno no es numerico.s
				java.util.Date date;
				try {
					date = newDate(Integer.parseInt(year.getText()),months.getSelectedIndex(),Integer.parseInt(day.getText()));
					concreteFlightCollection=businessLogic.getConcreteFlights(departCity.getSelectedItem().toString(),arrivalCity.getSelectedItem().toString(),date);

					for (ConcreteFlight f : concreteFlightCollection) 
						flightBoxNames.addElement(f.toString()); 
					if (concreteFlightCollection.isEmpty()) searchResult.setText("No flights in that city in that date");
					else searchResult.setText("Choose an available flight in this list:");
				} catch(Exception exc) {
					searchResult.setText("Año o dia no son numericos");
					date =newDate(Integer.parseInt("1992"),months.getSelectedIndex(),Integer.parseInt("10"));
				}
			}
		});
		lookforFlights.setBounds(81, 90, 261, 40);
		contentPane.add(lookforFlights);	
		
		jLabelResult = new JLabel("");
		jLabelResult.setBounds(109, 180, 243, 16);
		contentPane.add(jLabelResult);
		
		
		bookFlight = new JButton("");
		bookFlight.setEnabled(false);
		bookFlight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				touristTicket.setEnabled(false);
				touristTicket.setSelected(false);
				bussinesTicket.setEnabled(false);
				bussinesTicket.setSelected(false);
				firstTicket.setEnabled(false);
				firstTicket.setSelected(false);
				bookFlight.setEnabled(false);
				
				boolean exito = false;
				String tipo = null;
				if(bussinesTicket.isSelected()) {
					tipo = "bussines";
				}
				if(touristTicket.isSelected()) {
					tipo = "tourist";
				}
				if(firstTicket.isSelected()) {
					tipo = "first";
				}
				
				exito = businessLogic.reservarAsiento(selectedConcreteFlight, tipo);
				
				if (!exito) bookFlight.setText("Error: There were no seats available!");
				else{
					if(tipo == "bussines") {
						bookFlight.setText("Booked. #seat left: " + selectedConcreteFlight.getBusinessNumber());
					}else if(tipo == "tourist") {
						bookFlight.setText("Booked. #seat left: " + selectedConcreteFlight.getTouristNumber());
					}else if(tipo == "first") {
						bookFlight.setText("Booked. #seat left: " + selectedConcreteFlight.getFirstNumber());
					}
				}

				flightBoxNames.removeAllElements();
			}
			
		});
		bookFlight.setBounds(31, 273, 399, 40);
		contentPane.add(bookFlight);

		year = new JTextField();
		year.setText("2023");
		year.setBounds(57, 57, 50, 26);
		contentPane.add(year);
		year.setColumns(10);
		
		lblArrivalCity.setBounds(21, 39, 84, 16);
		contentPane.add(lblArrivalCity);
		searchResult.setBounds(57, 130, 314, 16);
	
		
	}
}  //  @jve:decl-index=0:visual-constraint="18,9"